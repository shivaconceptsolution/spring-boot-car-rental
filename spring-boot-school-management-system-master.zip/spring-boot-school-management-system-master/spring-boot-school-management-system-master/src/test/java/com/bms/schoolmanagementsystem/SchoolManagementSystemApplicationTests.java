package com.bms.schoolmanagementsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SchoolManagementSystemApplicationTests {

    @Test
    void contextLoads() {
    }

}
