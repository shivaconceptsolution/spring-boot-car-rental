package com.bms.schoolmanagementsystem.dto.request.address;

public class UpdateAddressRequest extends BaseAddressRequest {
}
