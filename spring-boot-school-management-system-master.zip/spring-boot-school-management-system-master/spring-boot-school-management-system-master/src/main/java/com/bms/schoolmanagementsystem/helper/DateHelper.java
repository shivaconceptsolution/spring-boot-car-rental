package com.bms.schoolmanagementsystem.helper;

import java.util.Date;

public class DateHelper {
    public static Date getCurrentDate() {
        return new Date();
    }
}
