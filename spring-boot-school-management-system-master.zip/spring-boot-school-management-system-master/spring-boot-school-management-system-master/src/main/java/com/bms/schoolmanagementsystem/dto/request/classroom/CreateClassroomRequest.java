package com.bms.schoolmanagementsystem.dto.request.classroom;

public class CreateClassroomRequest extends BaseClassroomRequest{
}
