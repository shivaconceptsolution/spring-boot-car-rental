package com.bms.schoolmanagementsystem.dto;

public record TeacherClassroomDto(
        String id,
        String name
) {
}
