package com.example.carrentalproject.exception;

public class ExistingEntityException extends RuntimeException {

        public ExistingEntityException(String message) {
                super(message);
        }

}
