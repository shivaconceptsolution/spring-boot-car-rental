package com.example.carrentalproject.exception;

public class UnavailableCarException extends RuntimeException {

        public UnavailableCarException(String message) {
                super(message);
        }

}
