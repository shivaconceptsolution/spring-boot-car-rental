package com.example.carrentalproject.exception;

public class AssignedRoleException extends RuntimeException{

        public AssignedRoleException(String message) {
                super(message);
        }

}
