package com.example.carrentalproject.constant;

public enum FuelType {
        PETROL,
        DIESEL,
        LPG,
        ELECTRIC
}
