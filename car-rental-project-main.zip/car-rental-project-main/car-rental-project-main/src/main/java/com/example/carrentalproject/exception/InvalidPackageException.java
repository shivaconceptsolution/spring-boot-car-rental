package com.example.carrentalproject.exception;

public class InvalidPackageException extends RuntimeException {

        public InvalidPackageException(String message) {
                super(message);
        }

}
