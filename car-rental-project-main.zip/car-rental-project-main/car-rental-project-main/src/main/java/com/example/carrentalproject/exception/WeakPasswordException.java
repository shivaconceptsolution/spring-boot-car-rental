package com.example.carrentalproject.exception;

public class WeakPasswordException extends RuntimeException {

        public WeakPasswordException(String message) {
                super(message);
        }

}
