package com.example.carrentalproject.constant;

public enum GearBoxType {
        MANUAL,
        AUTOMATIC
}
